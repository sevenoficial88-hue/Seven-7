import os,json,re,base64
from collections import Counter
from flask import Flask,request,jsonify,send_from_directory
import requests
app=Flask(__name__)
app.config['MAX_CONTENT_LENGTH']=10*1024*1024
ALLOWED={'png','jpg','jpeg','webp'}
@app.get('/')
def home(): return send_from_directory('.', 'index.html')
@app.get('/<path:name>')
def assets(name):
    if name in ('style.css','script.js'): return send_from_directory('.',name)
    return jsonify(error='Não encontrado'),404
def stats(s):
    n=len(s); c=Counter(s); out={'total':n,'frequencia':dict(c),'janelas':{str(k):dict(Counter(s[-k:])) for k in (5,10,20,50)},'alternancias':sum(s[i]!=s[i-1] for i in range(1,n)),'ngrams':{},'transicoes':{},'intervalos_empate':[],'maior_sequencia':{}}
    for x in 'JBE':
        best=run=0
        for y in s: run=run+1 if y==x else 0; best=max(best,run)
        out['maior_sequencia'][x]=best
    tr={}
    for a,b in zip(s,s[1:]): tr.setdefault(a,Counter())[b]+=1
    out['transicoes']={k:dict(v) for k,v in tr.items()}
    for k in range(2,6): out['ngrams'][str(k)]=dict(Counter(''.join(s[i:i+k]) for i in range(max(0,n-k+1))).most_common(10))
    pos=[i for i,x in enumerate(s) if x=='E']; out['intervalos_empate']=[pos[i]-pos[i-1] for i in range(1,len(pos))]
    return out
@app.post('/api/analyze-image')
def analyze():
    f=request.files.get('image')
    if not f or '.' not in f.filename or f.filename.rsplit('.',1)[1].lower() not in ALLOWED: return jsonify(error='Seleciona uma imagem JPG, PNG ou WEBP.'),400
    key=os.getenv('OPENROUTER_API_KEY'); model=os.getenv('VISION_MODEL')
    if not key or not model: return jsonify(status='IMAGEM RECEBIDA — IA NÃO CONFIGURADA',summary='Configura OPENROUTER_API_KEY e VISION_MODEL nos Secrets do servidor. Nenhuma sequência foi inventada.',sequence=[],methods_executed=0,image_quality='Leitura pendente',analysis={'estado':'Modelo de visão ainda não configurado.'})
    try:
        raw=f.read(); mime=f.mimetype or 'image/jpeg'; url='data:'+mime+';base64,'+base64.b64encode(raw).decode()
        payload={'model':model,'temperature':0,'messages':[{'role':'system','content':'Lê apenas resultados Bac Bo claramente visíveis. J=Jogador, B=Banca, E=Empate. Não adivinhes. Responde apenas JSON: {"sequence":["J"],"image_quality":"boa|media|fraca","uncertain":true,"notes":"..."}. Se ilegível, sequence: [].'},{'role':'user','content':[{'type':'text','text':'Extrai os resultados pela ordem visível.'},{'type':'image_url','image_url':{'url':url}}]}]}
        r=requests.post('https://openrouter.ai/api/v1/chat/completions',headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},json=payload,timeout=40);r.raise_for_status()
        text=r.json()['choices'][0]['message']['content']; m=re.search(r'\{.*\}',text,re.S)
        if not m: raise ValueError('JSON não recebido')
        d=json.loads(m.group()); seq=[x for x in d.get('sequence',[]) if x in 'JBE']
        return jsonify(status='ANÁLISE DESCRITIVA' if seq else 'SEM LEITURA CONFIÁVEL',summary=d.get('notes','Análise dos elementos legíveis.') if seq else 'Não foi possível confirmar uma sequência. Tenta uma captura mais nítida.',sequence=seq,methods_executed=25 if seq else 0,image_quality=d.get('image_quality','não avaliada'),analysis=stats(seq))
    except Exception:
        app.logger.exception('Falha na visão')
        return jsonify(error='Falha na análise. Confirma a chave, o modelo de visão e a ligação.'),502
@app.get('/api/health')
def health(): return jsonify(status='ok',vision_configured=bool(os.getenv('OPENROUTER_API_KEY') and os.getenv('VISION_MODEL')))
if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.getenv('PORT',5000)))
