# SEVEN BOT — BAC BO MASTER

## Conteúdo
Frontend minimalista, backend Flask e endpoint de análise de imagem via modelo de visão configurado na OpenRouter.

## Replit
1. Cria um Repl Python e envia todos estes ficheiros para a raiz.
2. Em Secrets, cria `OPENROUTER_API_KEY` e `VISION_MODEL`.
3. Instala: `pip install -r requirements.txt`
4. Executa: `python app.py`
5. Publica o backend num alojamento compatível com Python.

## Configuração
Escolhe na OpenRouter um modelo que aceite imagens e confirma o ID, preço e limites atuais. Não publiques a chave da API.

## Limitações
Não existe integração com Elephant Bet, leitura de vídeo em direto, apostas automáticas, conselho de 12 modelos ou supervisor nesta versão. A leitura depende da imagem. Estatísticas históricas não garantem o próximo resultado. A publicação como site estático na Vercel não executa este backend Flask sem adaptação.
